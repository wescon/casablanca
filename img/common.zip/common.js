﻿(function($) {

	$(document).bind('ready', function(){
					
		$('a[href^="#"]').bind('click', function () {
			scrollPage($(this));
	   });

	});

	function scrollPage(objLink) {
		var page = $('html,body'),
			elementClick = objLink.attr('href'),
		    destination = $(elementClick).offset().top;

		page.animate( { scrollTop: destination }, 1000 );
	}

})(jQuery);